helm repo add bitnami https://charts.bitnami.com/bitnami
helm install my-mariadb bitnami/mariadb



