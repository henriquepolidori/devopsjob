# devopsjob
Enviormnent

Install Docker Desktop and enable kubernetes option

Dockerfile build Ubuntu and setup Python Enviromnent

docker build -f Dockerfile -t ubuntu:test .

helm package Manager

helm repo add bitnami https://charts.bitnami.com/bitnami
helm install my-mariadb bitnami/mariadb

Connect from Ubuntu python script to mariadb database

Use script.py to connect from ubuntu container to mariadb datababase (Helm chart)
